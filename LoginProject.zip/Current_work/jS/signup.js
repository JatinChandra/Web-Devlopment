function itsotpturn() {
  if( document.getElementById("validotp").style.display == 'none' ){
    document.getElementById("validotp").style.display = 'inline';
  }
  else if (document.getElementById("validotp").style.display == 'inline') {
    document.getElementById("validotp").style.display = 'none';
  }
}
function itsnameturn() {
  if( document.getElementById("validname").style.display == 'none' ){
    document.getElementById("validname").style.display = 'inline';
  }
  else if (document.getElementById("validname").style.display == 'inline') {
    document.getElementById("validname").style.display = 'none';
  }
}
function validation() {
  var un = document.getElementById("UN");
  var mn = document.getElementById("MN");
  var no = document.getElementById("MN").value;
  var up = document.getElementById("UP");
  var cp = document.getElementById("CP");
  var dob = document.getElementById("DOB");
  var result = true;
  var checkanother = true;
  if(un.value.length<3 && checkanother){
    result = false;
    checkanother = false;
    alert("Invalid username");
  }else if (mn.value.length != 10 && checkanother) {
    result = false;
    checkanother = false;
    alert("Invalid Phone number");
  }else if (mn.value.length == 10 && !no.match(/^[7-9]{1}[0-9]{9}$/i) &&checkanother) {
      result = false;
      checkanother = false;
      alert("Invalid Phone number");
  }else if (dob.value == 'null' && checkanother) {
    result = false;
    checkanother = false;
    alert("Invalid Date of Birth");
  }else if (up.value.length <6 && checkanother) {
    result = false;
    checkanother = false;
    alert("Invalid Password");
  }else if (up.value != cp.value && checkanother) {
    result = false;
    checkanother = false;
    alert("Password did not matched")
  }
  return (result);

}
function viewallp() {
  var password = document.getElementById("UP");
  if(password.type === 'password')
   password.type = 'text';
  else {
    password.type = 'password';
  }
}
function viewallcp() {
  var password = document.getElementById("CP");
  if(password.type === 'password')
   password.type = 'text';
  else {
    password.type = 'password';
  }
}
