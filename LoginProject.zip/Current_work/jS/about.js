// document.write("Hello World!");

function changediv(imagenumber,imagename,imgnumber) {
  var newimg = document.getElementById("ibros");
  document.getElementById("nbros").innerHTML = imagename;
  document.getElementById("imgn").innerHTML = imgnumber;
  newimg.src = imagenumber;
  // newimg.transition = "all 2s";
}
