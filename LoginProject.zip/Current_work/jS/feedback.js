function toggledisplay() {
  document.getElementById("pu").style.height = "100%";
  document.getElementById("pu").style.border = "none";
  document.getElementById("pu").style.borderBottom = "3px solid YELLOW";
  document.getElementById("pu").style.borderTop = "3px solid YELLOW";
}
window.onclick = function(event) {
    if (event.target == pu) {
      document.getElementById("pu").style.height = "0%";
      document.getElementById("pu").style.border = "none";
    }
}
