<?php
session_start();
$un = $_POST['un'];
if (empty($un)){
  header("location:http://localhost/resolve/Current_work/Php/Signup.php");
}
else{
  $_SESSION['signupcheck'] = $un;
  $sex = $_POST['sex'];
  $un = $_POST['un'];
  $dob = $_POST['dob'];
  $mn = $_POST['mn'];
  $up = $_POST['up'];

  $con = mysqli_connect('localhost','jeetu','jeetu','webD');

  $q = "select * from usersinfo where BINARY username = '$un' OR mobil_no = $mn;";
  $check = mysqli_query($con,$q);
  $numberOfRows=mysqli_num_rows($check);

  if($numberOfRows > 0){
    mysqli_close($con);
    $error = "Username or Mobile number already registered";
    $_SESSION['hereistheerror'] = $error;
    header("location:http://localhost/resolve/Current_work/Php/Signup.php");
  }
  else {
    $shapass = sha1($up);
    $q = "insert into usersinfo(username ,sex, mobil_no ,dob , password, user_bio,initate__date) values ('$un','$sex' , $mn , '$dob' ,'$shapass' , NULL , CURDATE())";
    $check = mysqli_query($con,$q);
    mysqli_close($con);
    if($check){
        $_SESSION['gotocheck'] = "forgotocheck";
        header("location:http://localhost/resolve/Current_work/Php/Gotopage.php");
    }
    else {
      mysqli_close($con);
      $error = "Error occured during signup please try again with different username";
      $_SESSION['hereistheerror'] = $error;
      header("location:http://localhost/resolve/Current_work/Php/Signup.php");
    }
  }
}
?>
<!-- php end -->
