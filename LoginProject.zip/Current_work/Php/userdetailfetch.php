<?php
session_start();
if(!isset($_SESSION['homefromlogin'])){
  $invalidentry = "You must have to login from your account";
  $_SESSION['invalidentry'] = $invalidentry;
  header("location:http://localhost/resolve/Current_work/Php/Login.php");
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>HOME</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript">
      function logout() {
        window.alert('Succesfully Logout');
        window.location.href='http://localhost/resolve/Current_work/Php/Loginoutpage.php';
      }
    </script>
  </head>
  <body>
      <?php
          $commingdata = $_SESSION['homefromlogin'];
          $con = mysqli_connect('localhost','jeetu','jeetu','webD');
          if(preg_match("/^[7-9]{1}[0-9]{9}$/",$commingdata)){
            $qerno = "select * from usersinfo where mobil_no = '$commingdata';";
            $result = mysqli_query($con , $qerno);
            $nofrows = mysqli_num_rows($result);
            for($i=1;$i<=$nofrows;$i++){
               $value = mysqli_fetch_array($result);
               $userdetails = array("user_name"=>$value['username'] , "mobil_no"=>$value['mobil_no'] , "sex"=>$value['sex'] , "Initial_date"=>$value['initate__date']);
             }
          }
          else {
            $qerno = "select * from usersinfo where username = '$commingdata';";
            $result = mysqli_query($con , $qerno);
            $nofrows = mysqli_num_rows($result);
            for($i=1;$i<=$nofrows;$i++){
                $value = mysqli_fetch_array($result);
                $userdetails = array("NAME"=>$value['username'] , "NUMBER"=>$value['mobil_no'] , "GENDER"=>$value['sex'] , "DATE_OF_BIRTH"=>$value['dob']);
              }
          }


      ?>
      <h1>Welcome <?php echo $userdetails['NAME'] ?></h1>
      <h3>Here's your details</h3>

    <table>
      tr
    </table>

    <button type="button" onclick="logout()">Logout</button>
  </body>
</html>
