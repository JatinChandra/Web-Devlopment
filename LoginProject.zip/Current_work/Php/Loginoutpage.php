<?php
session_start();
 header("location:http://localhost/resolve/Current_work/Php/Login.php");
session_destroy();
?>
