<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <link rel="stylesheet" href="../css/signup.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
    <script type="text/javascript" src="../jS/feedback.js"></script>
    <script type="text/javascript" src="../jS/signup.js"></script>
  </head>
  <body>
    <!-- HEADER DIV -->
    <div class="header">
      <div class="brand">
        <a href="#" title="JJ"><img src="../resource/icon.png" alt="Image not found" height="80px" width="80px"></a>
      </div>

      <div class="webname">
        <h1 class="hwebname"><a class="awebname" href="#" title="JATIN CHANDRA">brand-name</a></h1>
      </div>

      <div class="menu item">
        <ul class="ulmenu">
          <li class="limenu"><a href="Ping.php" title="Home">HOME</a></li>
          <li class="limenu"><a href="About.html" title="About">ABOUT</a></li>
          <li class="limenu"><a href="Contact.html" title="Contact">CONTACT</a></li>
          <li class="limenu"><a href="#" title="Feedback" onclick="toggledisplay()">FEEDBACK</a></li>
        </ul>
      </div>

    </div>

    <!-- CONTAINER DIV -->
    <div class="container">

      <div class="popup" id="pu">
        <form class="popupform" action="index.html" method="post">
          <!-- <span class="closebtn" id="puf" onclick="blocktonone()">&times;</span> -->
          <input class="eupu elements" id="EUPU" type="text" name="epopup" placeholder="email or username" autocomplete="off" required>
          <input class="ppu elements" id="PPU" type="password" name="ppopup" placeholder="password" required>
          <textarea class="tapu elements" id="TAPU" name="fpopup" placeholder="Enter your feedback here ." autocomplete="off" required></textarea></br>
          <input class="spu elements" id="SPU" type="submit" value="Submit">
          <!-- <span>&gt;&gt;</span> -->
        </form>
      </div>

    <div class="insidecontainer">
      <!-- leftfieldset -->
      <div class="otherthanform ogbb">

          <div class="signuptext">
            <div class="signupheader">
              <h1 title="SIGN UP">SIGN UP</h1>
            </div>
            <div class="signuppara">
              <p>(Here you can sign up with your details)</p>
            </div>
          </div>

          <!-- Terms and conditions -->
          <div class="tandc">
            <fieldset>
              <legend title="Terms and Conditions">T&C*</legend>
                <div class="tcwarning">
                  <p>If you submit this signup form to us then you are automatically agree for the website terms
                    and conditions.</p>
                  <p><strong>PLEASE READ THIS AGREEMENT CAREFULLY</strong>. By submitting your application and by your use of the Service,
                     you agree to comply with all of the terms and conditions set out in this Agreement.
                     Website.com may terminate your account at any time, with or without notice,
                     for conduct that is in breach of this Agreement, for conduct that yunkaiitasu.com believes is
                     harmful to its business, or for conduct where the use of the Service is harmful to
                    any other party.</p>
                </div>
            </fieldset>
          </div>

          <div class="gotologin">
            <div class="gotologintext">
              <p><span>Already sign in , "</span>&nbsp;<a href="Login.php" class="agotologin" title="LOGIN HERE">Login</a>
                <span> " here.</span>&nbsp;</p>
            </div>
          </div>

      </div>
        <!-- rightfieldset -->
      <div class="form fgtb">
        <form class="signup" action="signupValidate.php" method="post" onsubmit="return validation()">
          <fieldset>
            <legend title="SIGN UP">Sign up</legend>

              <!-- Error message for unsuccesfull sign up -->
              <p id="errormsg" style="color:RED; font-family:serif; font-size: 13px;">
                <?php
                  if(isset($_SESSION['hereistheerror'])){
                    echo $_SESSION['hereistheerror'];
                    unset($_SESSION['hereistheerror']);
                  }
                 ?>
              </p>

            <!-- Element 1(Gender) -->
            <div class="gender">
              <label class="glabel">Gender</label>

              <!--Radio Buttons DIV-->
              <div class="gbuttons">
                <!--Radio Button-Male-->
                <label class="radio male">
                  <input id="male" type="radio" value="M" name="sex" checked="checked" id="mle"/>Male
                </label>
                <!--Radio Button-Female-->
                <label class="radio female">
                  <input id="female"type="radio" value="F" name="sex" id="fle" />Female
                </label>
                <!--Radio Button-Others-->
                <label class="radio secret">
                  <input id="secret"type="radio" value="S" name="sex" id="ole" />Secret
                </label>
              </div><!--End of div(gbuttons-RBs)-->
            </div><!--End of div(Element 1-Gender)-->

            <!-- Element 2(Username) -->
            <div class="username">
              <label class="ulabel" for="UN" >Username</label>
              <div class="utext">
                <input class="iutext" id="UN" type="text" name="un" placeholder="e.g. jeetu" onblur="itsnameturn()" onfocus="itsnameturn()" autocomplete="off" required>
              </div>
              <p id="validname" style=" color: RED; font-size:.7em; display:none; font-family: serif; ">Username must be unique.</p>
            </div>

            <!-- Element 3(data of birth) -->
            <div class="dateofbirth">
              <label class="doblabel" for="DOB" >Date of birth</label>
              <div class="dobtext">
                <input class="idobtext" id="DOB" type="date" name="dob" value="2000-12-01" required>
              </div>
            </div>

            <!-- Element 4(Mobil number) -->
            <div class="mobilenumber">
              <label class="mnlabel" for="MN" >Mobile number</label>
              <div class="mntext">
                <input class="imntext" id="MN" type="number" name="mn" placeholder="0123456789" onfocus="itsotpturn()" onblur="itsotpturn()" required >
              </div>
              <p id="validotp" style=" color: RED; font-size:.7em; display:none; font-family: serif; ">We send you an OTP to that number so please provide an valid number.</p>
            </div>

            <!-- Element 5(password) -->
            <div class="password">
              <label class="plabel" for="UP" >Password</label>
              <div class="ptext">
                <input class="iptext" id="UP" type="password" name="up" placeholder="minimum 6 char" required>
                <input class="icbtext" id="cbfp"type="checkbox">
                <label for="cbfp" onclick="viewallp()">sp</label>
              </div>
            </div>

            <!-- Element 6(Confirm-Password) -->
            <div class="confirmpassword">
              <label class="cplabel" for="CP" >Confirm password</label>
              <div class="cptext">
                <input class="icptext" id="CP" type="password" name="cp" placeholder="same as above" required>
                <input class="icbtext" id="cbfcp"type="checkbox">
                <label for="cbfcp" onclick="viewallcp()">sp</label>
              </div>
            </div>

            <!-- Element 7(biography) -->
            <div class="biography">
              <label class="blabel" for="BIO" >Bio</label>
              <div class="btext">
                <textarea class="ibtext" id="BIO" type="textarea" name="cp" rows="80" cols="80" placeholder="write about yourself"></textarea>
              </div>
            </div>

            <!-- Submit here -->
            <div class="submithere">
              <input id="SH" type="submit" value="Submit" title="SIGN UP">
              <input id="RA" type="reset" value="Reset" title="RESEL ALL">
            </div>
          </fieldset>
        </form>
      </div>
    </div>

    </div>

    <!-- FOOTER -->
    <div class="footer">
      <div class="links">
          <li class="linkmenu"><a href="#" title="Terms of use">Terms of use</a></li>
          <li class="linkmenu"><a href="#" title="Privacy policy">Privacy policy</a></li>
          <li class="linkmenu"><a href="#" title="FAQ">FAQ</a></li>
          <li class="linkmenu"><a href="#" title="Write for us">Write for us</a></li>
          <li class="linkmenu"><a href="#" title="Read me">Read me</a></li>
      </div>
      <div class="shareus sutl">
        <div class="sharetext">
        <h6 id="cprt">&copy copyright issue 2018</h6>
          <h5>SHARE US : </h5>
          <h6>You can share this website to your friends.</h6>
        </div>
        <div class="sharelink">
          <a href="#" class="fa fa-facebook" title="FACEBOOK"></a>
          <a href="#" class="fa fa-twitter" title="TWITTER"></a>
          <a href="#" class="fa fa-google" title="GOOGLE"></a>
          <a href="#" class="fa fa-youtube" title="YOUTUBE"></a>
          <a href="#" class="fa fa-whatsapp" title="WHATSAPP"></a>
          <a href="#" class="fa fa-instagram" title="INSTAGRAM"></a>
        </div>
      </div>
    </div>

  </body>
</html>
<?php
if (isset($_SESSION['succesfullfromgoto'])) {
  echo ("<script LANGUAGE='JavaScript'>
    window.alert('Succesfully Signup. Now you can login using Login page.');
    window.location.href='http://localhost/resolve/Current_work/Php/Login.php';
  </script>");
  unset($_SESSION['succesfullfromgoto']);
}
?>
