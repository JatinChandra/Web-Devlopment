<?php
session_start();
unset($_SESSION['gotocheck']);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LOGIN Page</title>
  <link rel="stylesheet" href="../css/login.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Shrikhand" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
  <script type="text/javascript" src="../jS/feedback.js"></script>
  <script type="text/javascript" src="../jS/login.js"></script>
</head>
<body>
  <!-- HEADER DIV -->
  <div class="header">

    <div class="brand">
      <a href="#" title="JJ"><img src="../resource/icon.png" alt="Image not found" height="80px" width="80px"></a>
    </div>

    <div class="webname">
      <h1 class="hwebname"><a class="awebname" href="#" title="JATIN CHANDRA">brand-name</a></h1>
    </div>

    <div class="menu item">
      <ul class="ulmenu">
        <li class="limenu"><a href="Ping.php" title="Home">HOME</a></li>
        <li class="limenu"><a href="About.html" title="About">ABOUT</a></li>
        <li class="limenu"><a href="Contact.html" title="Contact">CONTACT</a></li>
        <li class="limenu"><a href="#" title="Feedback" onclick="toggledisplay()">FEEDBACK</a></li>
      </ul>
    </div>

  </div>

  <!-- CONTAINER DIV -->
  <div class="container">

    <div class="popup" id="pu">
      <form class="popupform" action="index.html" method="post">
        <!-- <span class="closebtn" id="puf" onclick="blocktonone()">&times;</span> -->
        <input class="eupu elements" id="EUPU" type="text" name="epopup" placeholder="email or username" autocomplete="off" required>
        <input class="ppu elements" id="PPU" type="password" name="ppopup" placeholder="password" required>
        <textarea class="tapu elements" id="TAPU" name="fpopup" placeholder="Enter your feedback here ." autocomplete="off" required></textarea></br>
        <input class="spu elements" id="SPU" type="submit" value="Submit">
        <!-- <span>&gt;&gt;</span> -->
      </form>
    </div>

      <!-- rightfieldset -->
    <div class="form">
      <form class="login" action="loginValidation.php" method="post">

        <!-- login form logo -->
        <div class="forcircle">
          <div class="stroke">
            <img src="../resource/Login_logo.jpg" alt="Logo">
          </div>
        </div>

        <!-- Brand NAME -->
        <div class="brandnameinform">
          <h1>Start From Here</h1>
        </div>

        <fieldset class="loginfield">
          <legend title="LOGIN HERE">LOGIN HERE</legend>
            <p style="color:RED; font-family:serif; font-size: 13px;">
              <?php
                if(isset($_SESSION['loginerrormsg'])){
                    echo $_SESSION['loginerrormsg'];
                    unset($_SESSION['loginerrormsg']);
                }elseif(isset($_SESSION['invalidentry'])){
                  echo $_SESSION['invalidentry'];
                  unset($_SESSION['invalidentry']);
                }
              ?>
            </p>
          <!-- Element 1(Username) -->
          <div class="username">
            <!-- <label class="ulabel" for="UN" >Username</label> -->
            <div class="utext">
              <input class="iutext" id="UN" type="text" name="lun" placeholder="Username or Number" autocomplete="off" required>
            </div>
          </div>

          <!-- Element 2(password) -->
          <div class="password">
            <!-- <label class="plabel" for="UP" >Password</label> -->
            <div class="ptext">
              <input class="iptext" id="UP" type="password" name="lup" placeholder="Password" required>
              <input class="icbtext" id="cbfp"type="checkbox">
              <label for="cbfp" onclick="viewallp()">SP</label>
            </div>
          </div>

          <!-- Submit here -->
          <div class="submithere">
            <input id="SH" type="submit" value="LOGIN" title="LOGIN">
          </div>

        <!-- Element 4(Forget password) -->
        <div class="forgetpassword">
          <p><a href="#">Having any problem ?</a></p>
        </div>

        <!-- Element 5(sign up) -->
        <div class="gotosignup">
          <p><a href="Signup.php">Want to create new one ?</a></p>
        </div>

        </fieldset>
      </form>
    </div>
  </div>
  </div>

  <!-- FOOTER -->
  <div class="footer">
    <div class="links">
        <li class="linkmenu"><a href="#" title="Terms of use">Terms of use</a></li>
        <li class="linkmenu"><a href="#" title="Privacy policy">Privacy policy</a></li>
        <li class="linkmenu"><a href="#" title="FAQ">FAQ</a></li>
        <li class="linkmenu"><a href="#" title="Write for us">Write for us</a></li>
        <li class="linkmenu"><a href="#" title="Read me">Read me</a></li>
    </div>
    <div class="shareus sutl">
      <div class="sharetext">
        <h6 id="cprt">&copy copyright issue 2018</h6>
        <h5>SHARE US : </h5>
        <h6>You can share this website to your friends.</h6>
      </div>
      <div class="sharelink">
        <a href="#" class="fa fa-facebook" title="FACEBOOK"></a>
        <a href="#" class="fa fa-twitter" title="TWITTER"></a>
        <a href="#" class="fa fa-google" title="GOOGLE"></a>
        <a href="#" class="fa fa-youtube" title="YOUTUBE"></a>
        <a href="#" class="fa fa-whatsapp" title="WHATSAPP"></a>
        <a href="#" class="fa fa-instagram" title="INSTAGRAM"></a>
      </div>
    </div>
  </div>

</body>
</html>
