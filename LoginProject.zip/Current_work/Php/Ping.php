<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HOME Page</title>
  <link rel="stylesheet" href="../css/home.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Shrikhand" rel="stylesheet">
  <script type="text/javascript" src="../jS/feedback.js"></script>
</head>
<body>
  <!-- HEADER DIV -->
  <div class="header">

    <div class="brand">
      <a href="#" title="JJ"><img src="../resource/icon.png" alt="Image not found" height="80px" width="80px"></a>
    </div>

    <div class="webname">
      <h1 class="hwebname"><a class="awebname" href="#" title="JATIN CHANDRA">brand-name</a></h1>
    </div>

    <div class="menu item">
      <ul class="ulmenu">
        <li class="limenu"><a href="Ping.php" title="Home">HOME</a></li>
        <li class="limenu"><a href="About.html" title="About">ABOUT</a></li>
        <li class="limenu"><a href="Contact.html" title="Contact">CONTACT</a></li>
        <li class="limenu"><a href="#" title="Feedback" onclick="toggledisplay()" >FEEDBACK</a></li>
      </ul>
    </div>

  </div>

  <!-- CONTAINER DIV -->
  <div class="container">

    <!-- FEEDBACK -->
    <div class="popup" id="pu">
      <form class="popupform" action="index.html" method="post">
        <!-- <span class="closebtn" id="puf" onclick="blocktonone()">&times;</span> -->
        <input class="eupu elements" id="EUPU" type="text" name="epopup" placeholder="email or username" autocomplete="off" required>
        <input class="ppu elements" id="PPU" type="password" name="ppopup" placeholder="password" required>
        <textarea class="tapu elements" id="TAPU" name="fpopup" placeholder="Enter your feedback here ." autocomplete="off" required></textarea></br>
        <input class="spu elements" id="SPU" type="submit" value="Submit">
        <!-- <span>&gt;&gt;</span> -->
      </form>
    </div>

    <h3>NEW ON THIS PAGE</h3>
    <div class="dna">
      <p>WANT TO <a href="Login.php">LOGIN</a> OR CREATE A <a href="Signup.php">NEW ACCOUNT</a> ? </p>
    </div>

  </div>

  <!-- FOOTER -->
  <div class="footer">
    <div class="links">
        <li class="linkmenu"><a href="#" title="Terms of use">Terms of use</a></li>
        <li class="linkmenu"><a href="#" title="Privacy policy">Privacy policy</a></li>
        <li class="linkmenu"><a href="#" title="FAQ">FAQ</a></li>
        <li class="linkmenu"><a href="#" title="Write for us">Write for us</a></li>
        <li class="linkmenu"><a href="#" title="Read me">Read me</a></li>
    </div>
    <div class="shareus sutl">
      <div class="sharetext">
        <h6 id="cprt">&copy copyright issue 2018</h6>
        <h5>SHARE US : </h5>
        <h6>You can share this website to your friends.</h6>
      </div>
      <div class="sharelink">
        <a href="#" class="fa fa-facebook" title="FACEBOOK"></a>
        <a href="#" class="fa fa-twitter" title="TWITTER"></a>
        <a href="#" class="fa fa-google" title="GOOGLE"></a>
        <a href="#" class="fa fa-youtube" title="YOUTUBE"></a>
        <a href="#" class="fa fa-whatsapp" title="WHATSAPP"></a>
        <a href="#" class="fa fa-instagram" title="INSTAGRAM"></a>
      </div>
    </div>
  </div>

</body>
</html>
