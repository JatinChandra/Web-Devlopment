<?php

  $con = mysqli_connect('localhost','jeetu','jeetu','webD');
  if($con){
    echo "Connected";
  }else {
    echo "Error occured";
  }
  $qer = "select username from usersinfo where sex = 'm'";
  $result = mysqli_query($con , $qer);
  $n = mysqli_num_rows($result);
  if($n>0){
  echo "</br>Exist";
  }else {
    echo "</br>Nope";
  }
  mysqli_close($con);
  for ($i=1; $i <= $n ; $i++) {
    $row = mysqli_fetch_array($result);
    echo "</br>";
    echo $row["username"];
  }
?>
