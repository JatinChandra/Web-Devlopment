<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>FAKE</title>
    <link rel="stylesheet" href="../css/fake.css">
  </head>
  <body>
    <div class="forcheck">
      <form class="_form" action="test.php" method="post">
        <div class="sample">
          <div class="ques">
            <p>Is 5 < 2 ?</p>
          </div>
          <div class="sol">
            <input class="options" id="tr" type="radio" name="opts" value="TRUE">
            <label for="tr">TRUE</label>
            <input class="options" id="fl" type="radio" name="opts" value="FALSE">
            <label for="fl">FALSE</label>
            <input class="options" id="dnk" type="radio" name="opts" value="DNK">
            <label for="dnk">DO NOT KNOW</label>
          </div>
        </div>
        <div class="submitbutton">
          <input type="submit" value="Submit Answer" onsubmit="func()">
        </div>
      </form>
    </div>
  </body>
</html>
