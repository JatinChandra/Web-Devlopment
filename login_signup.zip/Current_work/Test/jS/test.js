// document.write("jS file included")
function changediv(imagenumber,imagename) {
  var newimg = document.getElementById("ibros");
  document.getElementById("nbros").innerHTML = imagename;
  newimg.src = imagenumber;
  // newimg.transition = "all 2s";
}
