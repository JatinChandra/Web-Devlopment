function viewallp() {
  var up = document.getElementById("UP");
  if(up.type === 'password'){
   up.type = 'text';
   up.style.width = "80%";
   up.style.height = "2.3em";
   up.style.textAlign = "center";
 }
  else {
    up.type = 'password';
    up.style.width = "80%";
    up.style.height = "2.3em";
    up.style.textAlign = "center";
  }
}
