<?php
session_start();
if(!isset($_SESSION['gotocheck'])){
    header("location:http://localhost/resolve/Current_work/Php/Signup.php");
}
else {
  $succesfullfromgoto = "Succesfully Signup. Now you can login using Login page.";
  $_SESSION['succesfullfromgoto'] = $succesfullfromgoto;
  header("location:http://localhost/resolve/Current_work/Php/Signup.php");
}
 ?>
