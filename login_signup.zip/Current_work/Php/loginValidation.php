<?php
session_start();
$lun = $_POST['lun'];
$lup = $_POST['lup'];

if (empty($un)){
  header("location:http://localhost/resolve/Current_work/Php/Login.php");
}

$n = sha1($lup);
$con = mysqli_connect('localhost','sql_user_name','sql_user_password','database_name');

if(preg_match("/^[7-9]{1}[0-9]{9}$/",$lun)){
    $qer = "select * from usersinfo where mobil_no = '$lun' AND password = '$n';";
}else {
    $qer = "select * from usersinfo where BINARY username = '$lun' AND password = '$n';";
}

$check = mysqli_query($con , $qer);
$nor = mysqli_num_rows($check);
mysqli_close($con);
if($nor > 0){

  $_SESSION['homefromlogin'] = $lun;
  header("location:http://localhost/resolve/Current_work/Php/Home.php");
  // header("location:http://localhost/resolve/Current_work/Php/userdetailfetch.php");
}
else {
  $loginerror = "Username and password not matched";
  $_SESSION['loginerrormsg'] = $loginerror;
  header("location:http://localhost/resolve/Current_work/Php/Login.php");
}
?>
